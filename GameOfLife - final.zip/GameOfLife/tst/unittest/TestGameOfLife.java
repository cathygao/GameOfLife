package unittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.scb.Game;

public class TestGameOfLife {

	private Game game;

	@Before
	public void setUp() throws Exception {
		game = new Game(4, 8);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testNeighbourCountSouldBeThree() {
		/** 
		 * Tester 		 : �� ��
		 * Description 	 : test the neighbor count of the given point should be three.
		 */
		int[][] map = { { 0, 0, 0, 0, 0, 0, 0, 0 }, 
					    { 0, 0, 0, 0, 1, 0, 0, 0 },
				        { 0, 0, 0, 1, 1, 0, 0, 0 }, 
				        { 0, 0, 0, 0, 0, 0, 0, 0 } };

		game.setStatus(map);

		int numNeighbour = game.numNeighbour(1, 3);
		assertEquals(3, numNeighbour);

	}

	@Test
	public void testStatusLiveWithNoNeighbourShouldBeDead() {
		/** 
		 * Tester 		 : ������
		 * Description 	 : test the live one with no neighbor should be Dead.
		 */
		int[][] map = { { 0, 0, 0, 0, 0, 0, 0, 0 }, 
						{ 0, 1, 0, 0, 1, 0, 0, 0 },
						{ 0, 0, 0, 1, 1, 0, 0, 0 }, 
						{ 0, 0, 0, 0, 0, 0, 0, 0 } };
		            game.setStatus(map);

				int nextStatus = game.calNextStatus(1, 1);
				assertEquals(0, nextStatus);

	}
	
	@Test
	public void testStatusLiveWithOneNeighbourShouldBeDead() {
		/** 
		 * Tester 		 : ������
		 * Description 	 : test the live one with one neighbour should be Dead.
		 */
		int[][] map = { { 0, 0, 0, 0, 0, 0, 0, 0 }, 
						{ 0, 1, 1, 0, 1, 0, 0, 0 },
						{ 0, 0, 0, 1, 1, 0, 0, 0 }, 
						{ 0, 0, 0, 0, 0, 0, 0, 0 } };
		            game.setStatus(map);

				int nextStatus = game.calNextStatus(1, 1);
				assertEquals(0, nextStatus);

	}

	@Test
	public void testStatusLiveWithFourNeighboursShouldBeDead() {
		/** 
		 * Tester 		 : ����
		 * Description 	 : test the live one with four neighbors should be Dead.
		 */
		int[][] map = { { 0, 0, 0, 0, 0, 0, 0, 0 }, 
					    { 0, 0, 1, 1, 1, 0, 0, 0 },
				        { 0, 0, 0, 1, 1, 0, 0, 0 }, 
				        { 0, 0, 0, 0, 0, 0, 0, 0 } };

		game.setStatus(map);
		int nextStatus = game.calNextStatus(1, 3);
		assertEquals(0, nextStatus);

	}
	
	@Test
	public void testStatusLiveWithTwoNeighboursStillBeLive() {
		/** 
		 * Tester 		 : ����
		 * Description 	 : test the live one with two neighbors still be alive.
		 */
		int[][] map = { { 0, 0, 0, 0, 0, 0, 0, 0 }, 
					    { 0, 0, 1, 1, 1, 0, 0, 0 },
					    { 0, 0, 1, 0, 1, 0, 0, 0 }, 
					    { 0, 0, 0, 0, 0, 0, 0, 0 } };

        game.setStatus(map);
		int nextStatus = game.calNextStatus(1, 2);
		assertEquals(1, nextStatus);

	}
	@Test
	public void testStatusLiveWithThreeNeighboursStillBeLive() {
		/** 
		 * Tester 		 : ����
		 * Description 	 : test the nextStatus of whole map the Boundary should be still dead.
		 */
		int[][] map = { { 0, 0, 0, 0, 0, 0, 0, 0 }, 
						{ 0, 0, 1, 1, 0, 0, 0, 0 },
						{ 0, 0, 1, 1, 0, 0, 0, 0 }, 
						{ 0, 0, 0, 0, 0, 0, 0, 0 } };

		game.setStatus(map);
		int nextStatus = game.calNextStatus(1, 3);
		assertEquals(1, nextStatus);

	}

	@Test
	public void testStatusDeadToLiveBoundaryStillBeDead() {
		/**
		  * Tester       : ��С��
		  * Description  : a dead cell with less than three live 
		  *                Neighbors will be still dead.
		  *                This case choose one of boundary case (0,1), 
		  *                the dead cell (0,1) will never becomes a live
		  *                cell, because we define all the boundary are dead cells.
		  */
		int[][] map = { { 0, 0, 0, 0, 0, 0 }, 
						{ 0, 1, 1, 1, 0, 0 },
						{ 0, 0, 1, 0, 0, 0 }, 
						{ 0, 0, 0, 0, 0, 0 } };

       game.setStatus(map);
		int nextStatus = game.calNextStatus(0, 1);
		assertEquals(0, nextStatus);
	}
	
	@Test
	public void testStatusDeadToLiveWithThreeNeighboursShouldBeLive() {
		/** 
		  * Tester       : ��С��
		  * Description  : a dead cell with exactly three live neighbors
		  *                will becomes a live cell.                
		  */
		int[][] map = { { 0, 0, 0, 0, 0, 0 }, 
						{ 0, 0, 1, 1, 0, 0 },
						{ 0, 1, 1, 0, 0, 0 }, 
						{ 0, 0, 0, 0, 0, 0 } };

       game.setStatus(map);
		int nextStatus = game.calNextStatus(1, 1);
		assertEquals(1, nextStatus);
	}
	
	@Test
	public void testStatusDeadToLiveWithFourNeighboursShouldBeDead() {
		/** 
		  * Tester      : ��С��
		  * Description : a dead cell with more than three live neighbors
		  *               will still be dead.
		  */
		int[][] map = { { 0, 0, 0, 0, 0, 0 }, 
						{ 0, 1, 1, 1, 0, 0 },
						{ 0, 0, 0, 1, 0, 0 }, 
						{ 0, 0, 0, 0, 0, 0} };

       game.setStatus(map);
		int nextStatus = game.calNextStatus(2, 2);
		assertEquals(0, nextStatus);
	}
	
	@Test
	public void testNeighbourCountOfLeftTopPointShouldBeOne() {
		/** 
		 * Tester 		 : �� �
		 * Description 	 : test the neighbor count of the left-top point,
		 * 				   which should be one.
		 */
		int[][] map = { { 0, 0, 0, 0, 0, 0, 0, 0 }, 
					    { 0, 1, 0, 0, 1, 0, 0, 0 },
				        { 0, 0, 0, 1, 1, 0, 0, 0 }, 
				        { 0, 0, 0, 0, 0, 0, 0, 0 } };

		game.setStatus(map);

		int numNeighbour = game.numNeighbour(0, 0);
		assertEquals(1, numNeighbour);

	}
	
	@Test
	public void testNeighbourCountOfRightDownPointShouldBeOne() {
		/** 
		 * Tester 		 : �� �
		 * Description 	 : test the neighbor count of right-down point,
		 * 				   which should be one.
		 */
		int[][] map = { { 0, 0, 0, 0, 0, 0, 0, 0 }, 
					    { 0, 1, 0, 0, 1, 0, 0, 0 },
				        { 0, 0, 0, 1, 1, 0, 1, 0 }, 
				        { 0, 0, 0, 0, 0, 0, 0, 0 } };

		game.setStatus(map);

		int numNeighbour = game.numNeighbour(3, 7);
		assertEquals(1, numNeighbour);

	}
	
	@Test
	public void testNeighbourCountOfTopPointShouldBeTwo() {
		/** 
		 * Tester 		: �� �
		 * Description 	: test the neighbor count of top point,
		 * 				  which should be two.
		 */
		int[][] map = { { 0, 0, 0, 0, 0, 0, 0, 0 }, 
					    { 0, 1, 1, 0, 1, 0, 0, 0 },
				        { 0, 0, 0, 1, 1, 0, 0, 0 }, 
				        { 0, 0, 0, 0, 0, 0, 0, 0 } };

		game.setStatus(map);

		int numNeighbour = game.numNeighbour(0, 2);
		assertEquals(2, numNeighbour);

	}
	
	@Test
	public void testNeighbourCountOfTopPointShouldBeThree() {
		/** 
		 * Tester 		: �� �
		 * Description 	: test the neighbor count of top point,
		 * 				  which should be three.
		 */
		int[][] map = { { 0, 0, 0, 0, 0, 0, 0, 0 }, 
					    { 0, 1, 1, 1, 1, 0, 0, 0 },
				        { 0, 0, 0, 1, 1, 0, 0, 0 }, 
				        { 0, 0, 0, 0, 0, 0, 0, 0 } };

		game.setStatus(map);

		int numNeighbour = game.numNeighbour(0, 2);
		assertEquals(3, numNeighbour);

	}
	
	@Test
	public void testNeighbourCountOfBottomPointShouldBeTwo() {
		/** 
		 * Tester 		: �� �
		 * Description 	: test the neighbor count of bottom point,
		 * 				  which should be two.
		 */
		int[][] map = { { 0, 0, 0, 0, 0, 0, 0, 0 }, 
					    { 0, 1, 0, 0, 1, 0, 0, 0 },
				        { 0, 0, 0, 1, 1, 0, 1, 0 }, 
				        { 0, 0, 0, 0, 0, 0, 0, 0 } };

		game.setStatus(map);

		int numNeighbour = game.numNeighbour(3, 4);
		assertEquals(2, numNeighbour);

	}
	
	@Test
	public void testNeighbourCountOfBottomPointShouldBeThree() {
		/** 
		 * Tester 		: �� �
		 * Description 	: test the neighbor count of bottom point,
		 * 				  which should be three.
		 */
		int[][] map = { { 0, 0, 0, 0, 0, 0, 0, 0 }, 
					    { 0, 1, 0, 0, 1, 0, 0, 0 },
				        { 0, 0, 0, 1, 1, 1, 1, 0 }, 
				        { 0, 0, 0, 0, 0, 0, 0, 0 } };

		game.setStatus(map);

		int numNeighbour = game.numNeighbour(3, 4);
		assertEquals(3, numNeighbour);

	}

	@Test
	public void testNeighbourCountOfRightestPointShouldBeTwo() {
		/** 
		 * Tester 		: �� �
		 * Description 	: test the neighbor count of rightest point,
		 * 				  which should be two.
		 */
		int[][] map = { { 0, 0, 0, 0, 0, 0, 0, 0 }, 
					    { 0, 1, 0, 0, 1, 0, 1, 0 },
				        { 0, 0, 0, 1, 1, 0, 1, 0 }, 
				        { 0, 0, 0, 0, 0, 0, 0, 0 } };

		game.setStatus(map);

		int numNeighbour = game.numNeighbour(1, 7);
		assertEquals(2, numNeighbour);

	}
	
	@Test
	public void testNextGeneral() {
		/** 
		 * Tester 		 : �� ��
		 * Description 	 : test the nextStatus of whole map.
		 */
		int[][] map = { { 0, 0, 0, 0, 0, 0, 0, 0 }, 
					    { 0, 1, 0, 0, 1, 0, 0, 0 },
				        { 0, 0, 0, 1, 1, 0, 0, 0 }, 
				        { 0, 0, 0, 0, 0, 0, 0, 0 } };

		game.setStatus(map);
				
		String nextStatus = game.nextStatus();

		String nextMap = "00000000" +  
			    		 "00011000" +
			    		 "00011000" +
			    		 "00000000";
	
		assertEquals(nextMap, nextStatus);

	}
	
	@Test
	public void testNextGeneralOfBoundary() {
		/** 
		 * Tester 		 : �� ��
		 * Description 	 : test the nextStatus of whole map.
		 */
		int[][] map = { { 0, 0, 0, 0, 0, 0, 0, 0 }, 
					    { 0, 1, 1, 1, 1, 0, 0, 0 },
				        { 0, 0, 0, 1, 1, 0, 0, 0 }, 
				        { 0, 0, 0, 0, 0, 0, 0, 0 } };

		game.setStatus(map);
				
		String nextStatus = game.nextStatus();

		String nextMap = "00000000" +  
			    		 "00101000" +
			    		 "00001000" +
			    		 "00000000";
	
		assertEquals(nextMap, nextStatus);

	}
	
}
